"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { Icon } from "@/components/icons";
import { GlobalSearch, SearchToggle } from "@/components/search/global-search";
import { SiteTranslator } from "@/components/site-translator";
import { useContentLang } from "@/lib/content-language";

export type MenuNode = {
  id: string;
  label: string;
  href?: string;
  children?: MenuNode[];
};

export type NavItem = {
  id: string;
  label: string;
  href?: string;
  items?: MenuNode[];
};

export const globalNavigation: NavItem[] = [
  {
    id: "beranda",
    label: "Beranda",
    href: "/",
  },
  {
    id: "profil",
    label: "Profil",
    href: "/profil",
    items: [
      { id: "sejarah", label: "Sejarah", href: "/profil/sejarah" },
      { id: "visi", label: "Visi & Misi", href: "/profil/visi-misi" },
      { id: "struktur", label: "Struktur Organisasi", href: "/profil/struktur-organisasi" },
      { id: "akreditasi", label: "Akreditasi", href: "/profil/akreditasi" },
      { id: "fasilitas", label: "Fasilitas Kampus", href: "/profil/fasilitas-kampus" },
      {
        id: "unit-bagian",
        label: "Unit dan Bagian",
        href: "/profil/unit-dan-bagian",
        children: [
          {
            id: "upt-komputer",
            label: "UPT Komputer",
            href: "/profil/unit-dan-bagian/upt-komputer",
            children: [
              {
                id: "blueprint-tik",
                label: "Blueprint TIK",
                href: "/profil/unit-dan-bagian/blueprint-tik",
              },
            ],
          },
          {
            id: "upt-perpustakaan",
            label: "UPT Perpustakaan",
            href: "/profil/unit-dan-bagian/upt-perpustakaan",
          },
          {
            id: "upt-humas",
            label: "UPT Humas dan Marketing",
            href: "/profil/unit-dan-bagian/upt-humas-marketing",
          },
          {
            id: "baaka",
            label: "BAAKA",
            href: "/profil/unit-dan-bagian/baaka",
          },
          {
            id: "bausk",
            label: "BAUSK",
            href: "/profil/unit-dan-bagian/bausk",
          },
          {
            id: "peraturan",
            label: "Peraturan",
            href: "/profil/unit-dan-bagian/peraturan",
          },
        ],
      },
    ],
  },
  {
    id: "akademik",
    label: "Akademik",
    href: "/akademik/fakultas",
    items: [
      { id: "fakultas", label: "Daftar Fakultas", href: "/akademik/fakultas" },
      {
        id: "program-studi",
        label: "Program Studi",
        children: [
          {
            id: "humaniora",
            label: "Humaniora dan Desain",
            href: "/akademik/programstudi/humanioradesain",
            children: [
              { id: "desain", label: "S1 Desain Komunikasi Visual", href: "/akademik/programstudi/humanioradesain/s1-dkv" },
              { id: "jepang", label: "S1 Bahasa Jepang", href: "/akademik/programstudi/humanioradesain/s1-bjepang" },
              { id: "inggris-d3", label: "D3 Bahasa Inggris", href: "/akademik/programstudi/humanioradesain/d3-bing" },
              { id: "inggris-s1", label: "S1 Bahasa Inggris", href: "/akademik/programstudi/humanioradesain/s1-bing" },
            ],
          },
          {
            id: "bisnis",
            label: "Sains dan Bisnis",
            href: "/akademik/programstudi/sainsdanbisnis",
            children: [
              { id: "digital", label: "S1 Bisnis Digital", href: "/akademik/programstudi/sainsdanbisnis/s1-bisnis-digital" },
              { id: "informatika", label: "S1 Informatika", href: "/akademik/programstudi/sainsdanbisnis/s1-informatika" },
              { id: "informasi", label: "S1 Sistem Informasi", href: "/akademik/programstudi/sainsdanbisnis/s1-sistem-informasi" },
            ],
          },
        ],
      },
      { id: "akreditasi", label: "Akreditasi Program Studi", href: "/akademik/akreditasi" },
      { id: "kalender", label: "Kalender Akademik", href: "/akademik/kalender-akademik" },
      { id: "kurikulum", label: "Kurikulum", href: "/akademik/kurikulum" },
    ],
  },
  {
    id: "pmb",
    label: "PMB",
    href: "/pmb",
  },
  {
    id: "lppm",
    label: "LPPM",
    href: "/lppm",
  },
  {
    id: "kehidupan",
    label: "Kehidupan Kampus",
    items: [
      { id: "ukm", label: "Kegiatan Mahasiswa (UKM)", href: "/kehidupan-kampus/kegiatan-mahasiswa" },
      { id: "berita", label: "Berita Terkini", href: "/kehidupan-kampus/berita-terkini" },
      { id: "pengumuman", label: "Pengumuman", href: "/kehidupan-kampus/pengumuman" },
      { id: "agenda", label: "Agenda Acara", href: "/kehidupan-kampus/agenda-acara" },
    ],
  },
  {
    id: "alumni",
    label: "Alumni",
    href: "/alumni",
    items: [
      { id: "ikatan", label: "Ikatan Alumni", href: "/alumni/ikatan-alumni" },
      { id: "tracer", label: "Tracer Study (Kuesioner Alumni)", href: "/alumni/tracer-study" },
      { id: "karier", label: "Info Lowongan Kerja (Career Center)", href: "/alumni/career-center" },
    ],
  },
  {
    id: "lpm",
    label: "LPM",
    href: "/lpm",
    items: [
      {
        id: "lpm-laporan",
        label: "Laporan LPM",
        href: "/lpm/laporan-lpm",
        children: [
          {
            id: "lpm-laporan-ami",
            label: "Laporan Tahunan Audit Mutu Internal Universitas LIA",
            href: "/lpm/laporan-lpm/laporan-tahunan-audit-mutu-internal",
            children: [
              {
                id: "lpm-ami-2025",
                label: "Laporan Tahunan Audit Mutu Internal 2025",
                href: "/lpm/laporan-lpm/laporan-tahunan-audit-mutu-internal/laporan-audit-mutu-internal-2025",
              },
            ],
          },
          {
            id: "lpm-laporan-rtm",
            label: "Laporan Tahunan RTM & RTL",
            href: "/lpm/laporan-lpm/laporan-tahunan-rtm-rtl",
            children: [
              {
                id: "lpm-rtm-2025",
                label: "Laporan RTM dan RTL 2025",
                href: "/lpm/laporan-lpm/laporan-tahunan-rtm-rtl/laporan-rtm-dan-rtl-2025",
              },
            ],
          },
          {
            id: "lpm-manajemen-arsip",
            label: "Management Arsip",
            href: "/lpm/manajemen-arsip",
          },
        ],
      },
      {
        id: "lpm-kegiatan",
        label: "Kegiatan LPM",
        href: "/lpm/kegiatan-lpm",
        children: [
          {
            id: "lpm-benchmarking",
            label: "Benchmarking",
            href: "/lpm/kegiatan-lpm/benchmarking",
          },
        ],
      },
    ],
  },
  {
    id: "laporan",
    label: "Laporan Tahunan Rektor",
    href: "/laporan-tahunan-rektor",
  },
];

type BreadcrumbItem = {
  label: string;
  href?: string;
};

const breadcrumbNavigation: MenuNode[] = globalNavigation.map((item) => ({
  id: item.id,
  label: item.label,
  href: item.href,
  children: item.items,
}));

function getNavigationTrail(pathname: string) {
  let bestMatch:
    | {
        href: string;
        trail: MenuNode[];
      }
    | undefined;

  function visit(nodes: MenuNode[], ancestors: MenuNode[] = []) {
    for (const node of nodes) {
      const trail = [...ancestors, node];
      const href = node.href?.split("#")[0];
      if (
        href &&
        (pathname === href || (href !== "/" && pathname.startsWith(`${href}/`))) &&
        (!bestMatch ||
          href.length > bestMatch.href.length ||
          (href.length === bestMatch.href.length &&
            trail.length > bestMatch.trail.length))
      ) {
        bestMatch = { href, trail };
      }
      if (node.children) visit(node.children, trail);
    }
  }

  visit(breadcrumbNavigation);
  return bestMatch;
}

function formatBreadcrumbLabel(segment: string) {
  const knownLabels: Record<string, string> = {
    "cara-pembayaran": "Cara Pembayaran",
    "jalur-rpl": "Jalur RPL",
    "pengunduran-diri": "Pengunduran Diri",
  };
  return (
    knownLabels[segment] ??
    segment
      .split("-")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  );
}

function getBreadcrumbItems(pathname: string): BreadcrumbItem[] {
  if (pathname === "/") return [{ label: "" }];

  if (pathname === "/pengunduran-diri") {
    return [
      { label: "PMB", href: "/pmb" },
      { label: "Pengunduran Diri" },
    ];
  }

  const match = getNavigationTrail(pathname);
  const items: BreadcrumbItem[] = match
    ? match.trail
        .filter(
          (item, index, trail) =>
            !item.href ||
            !trail
              .slice(index + 1)
              .some((laterItem) => laterItem.href === item.href),
        )
        .map((item) => ({ label: item.label, href: item.href }))
    : [];
  const matchedHref = match?.href ?? "";
  const remainingPath = pathname.slice(matchedHref.length);

  for (const segment of remainingPath.split("/").filter(Boolean)) {
    items.push({ label: formatBreadcrumbLabel(segment) });
  }

  return items.length > 0
    ? items
    : pathname
        .split("/")
        .filter(Boolean)
        .map((segment) => ({ label: formatBreadcrumbLabel(segment) }));
}

export function GlobalDropdownMenu({
  items,
  className = "menu-tree",
  onNavigate,
  pathname,
  expandActiveNodes = true,
}: {
  items: MenuNode[];
  className?: string;
  onNavigate: () => void;
  pathname: string;
  expandActiveNodes?: boolean;
}) {
  function resolveHref(href?: string) {
    if (!href) return "#";
    if (href.startsWith("/")) return href;
    if (pathname === "/") return href;
    return `/${href}`;
  }

  function isNodeActive(item: MenuNode): boolean {
    if (item.href) {
      const href = resolveHref(item.href);
      if (pathname === href || pathname.startsWith(`${href}/`)) return true;
    }
    return item.children?.some(isNodeActive) ?? false;
  }

  function getActiveNodeIds(nodes: MenuNode[]): Set<string> {
    const activeIds = new Set<string>();
    for (const node of nodes) {
      if (isNodeActive(node)) activeIds.add(node.id);
      if (node.children) {
        for (const id of getActiveNodeIds(node.children)) activeIds.add(id);
      }
    }
    return activeIds;
  }

  const [openNodes, setOpenNodes] = useState<Set<string>>(() =>
    expandActiveNodes ? getActiveNodeIds(items) : new Set(),
  );
  const activeNodeIds = getActiveNodeIds(items);

  function toggleNode(id: string) {
    setOpenNodes((current) => {
      const next = new Set(current);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  return (
    <ul className={className}>
      {items.map((item) => (
        <li
          className={`menu-branch${item.children ? " has-children" : ""}${!expandActiveNodes ? " lpm-menu-branch" : ""}${openNodes.has(item.id) || (expandActiveNodes && activeNodeIds.has(item.id)) ? " is-open" : ""}`}
          key={item.id}
        >
          {item.children ? (
            <div className="menu-link menu-link-branch">
              {item.href ? (
                <Link
                  aria-current={pathname === resolveHref(item.href) ? "page" : undefined}
                  className={`menu-link-label${isNodeActive(item) ? " is-active" : ""}`}
                  href={resolveHref(item.href)}
                  onClick={onNavigate}
                >
                  {item.label}
                </Link>
              ) : (
                <span className="menu-link-label">{item.label}</span>
              )}
              <button
                aria-expanded={openNodes.has(item.id) || (expandActiveNodes && activeNodeIds.has(item.id))}
                aria-label={`${openNodes.has(item.id) || (expandActiveNodes && activeNodeIds.has(item.id)) ? "Tutup" : "Buka"} submenu ${item.label}`}
                className="menu-link-toggle"
                onClick={() => toggleNode(item.id)}
                type="button"
              >
                <Icon name="chevron" size={14} />
              </button>
            </div>
          ) : (
            <Link
              aria-current={pathname === resolveHref(item.href) ? "page" : undefined}
              className={`menu-link${isNodeActive(item) ? " is-active" : ""}`}
              href={resolveHref(item.href)}
              onClick={onNavigate}
            >
              {item.label}
            </Link>
          )}
          {item.children && (
            <GlobalDropdownMenu
              className={`menu-children${!expandActiveNodes ? " lpm-menu-tree" : ""}`}
              items={item.children}
              onNavigate={onNavigate}
              pathname={pathname}
              expandActiveNodes={expandActiveNodes}
            />
          )}
        </li>
      ))}
    </ul>
  );
}

export function SiteHeader() {
  const pathname = usePathname();
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [lang, setLang] = useContentLang();
  const [searchOpen, setSearchOpen] = useState(false);
  const [isFloating, setIsFloating] = useState(false);
  const navRef = useRef<HTMLElement>(null);
  const searchTriggerRef = useRef<HTMLButtonElement>(null);

  const closeSearch = useCallback(() => setSearchOpen(false), []);

  function openSearch(event: React.MouseEvent<HTMLButtonElement>) {
    searchTriggerRef.current = event.currentTarget;
    setActiveMenu(null);
    setMobileMenuOpen(false);
    setSearchOpen(true);
  }

  useEffect(() => {
    let frame = 0;

    function updateFloatingState() {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const scrollY = window.scrollY;
        setIsFloating((current) => {
          if (!current && scrollY > 56) return true;
          if (current && scrollY < 12) return false;
          return current;
        });
      });
    }

    updateFloatingState();
    window.addEventListener("scroll", updateFloatingState, { passive: true });
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("scroll", updateFloatingState);
    };
  }, []);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (navRef.current && !navRef.current.contains(event.target as Node)) {
        setActiveMenu(null);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  function toggleMenu(id: string) {
    setActiveMenu((current) => (current === id ? null : id));
  }

  function resolveHref(href?: string) {
    if (!href) return "#";
    if (href.startsWith("/")) return href;
    if (pathname === "/") return href;
    return `/${href}`;
  }

  function isItemActive(item: NavItem): boolean {
    if (pathname === "/") {
      return item.id === "beranda";
    }
    if (item.id === "beranda") {
      return false;
    }
    if (item.id === "profil") {
      return pathname.startsWith("/profil");
    }
    if (item.id === "akademik") {
      return pathname.startsWith("/akademik");
    }
    if (item.id === "kehidupan") {
      return pathname.startsWith("/kehidupan-kampus");
    }
    if (item.id === "lpm") {
      return pathname.startsWith("/lpm");
    }
    if (item.id === "lppm") {
      return pathname.startsWith("/lppm");
    }
    if (item.id === "pmb") {
      return pathname.startsWith("/pmb") || pathname === "/pengunduran-diri";
    }
    if (item.id === "laporan") {
      return pathname.startsWith("/laporan-tahunan-rektor");
    }
    if (item.id === "alumni") {
      return pathname.startsWith("/alumni");
    }
    if (item.href && item.href.startsWith("/") && item.href !== "/" && pathname.startsWith(item.href)) {
      return true;
    }
    if (item.items) {
      const hasActiveChild = (nodes: MenuNode[]): boolean => {
        return nodes.some((node) => {
          if (node.href && node.href.startsWith("/")) {
            const pathOnly = node.href.split("#")[0];
            if (pathOnly && pathOnly !== "/" && (pathname === pathOnly || pathname.startsWith(`${pathOnly}/`))) {
              return true;
            }
          }
          return node.children ? hasActiveChild(node.children) : false;
        });
      };
      if (hasActiveChild(item.items)) {
        return true;
      }
    }
    return activeMenu === item.id;
  }

  if (pathname?.startsWith("/admin")) {
    return null;
  }

  return (
    <header className={`site-header${isFloating ? " is-floating" : ""}`}>
      <div className="header-inner">
        <div className="header-top-row">
          <Link aria-label="Universitas LIA, Beranda" className="brand" href="/">
            <Image
              alt="Universitas LIA"
              className="brand-logo"
              height={37}
              priority
              src="/Logo-Universitas-LIA-scaled.png"
              width={165}
            />
          </Link>
          <div className="header-meta-actions">
            <div aria-label="Pilih Bahasa" className="lang-switcher" role="group" translate="no">
              <button
                aria-pressed={lang === "id"}
                className={`lang-btn${lang === "id" ? " is-active" : ""}`}
                onClick={() => setLang("id")}
                type="button"
              >
                ID
              </button>
              <button
                aria-pressed={lang === "en"}
                className={`lang-btn${lang === "en" ? " is-active" : ""}`}
                onClick={() => setLang("en")}
                type="button"
              >
                EN
              </button>
            </div>

            <div className="search-wrap">
              <SearchToggle isOpen={searchOpen} onOpen={openSearch} />
            </div>
          </div>

          <button
            aria-expanded={mobileMenuOpen}
            aria-label={mobileMenuOpen ? "Tutup menu" : "Buka menu"}
            className="mobile-menu-toggle"
            onClick={() => setMobileMenuOpen((open) => !open)}
            type="button"
          >
            <Icon name={mobileMenuOpen ? "x" : "menu"} size={22} />
          </button>
        </div>

        <nav
          aria-label="Navigasi utama"
          className={`main-nav${mobileMenuOpen ? " mobile-open" : ""}`}
          onMouseLeave={(event) => {
            if (event.relatedTarget instanceof Node && navRef.current?.contains(event.relatedTarget)) {
              return;
            }
            setActiveMenu(null);
          }}
          ref={navRef}
        >
          {globalNavigation.map((item) => {
            const isActive = isItemActive(item);
            return (
              <div
                className={`nav-item${isActive ? " is-active" : ""}${item.id === "laporan" ? " nav-item-long" : ""}`}
                key={item.id}
                onMouseEnter={() => {
                  if (item.items && !mobileMenuOpen) setActiveMenu(item.id);
                }}
              >
                {item.items && !item.href ? (
                  <button
                    aria-expanded={activeMenu === item.id}
                    aria-haspopup="true"
                    className="nav-trigger"
                    onClick={() => {
                      if (mobileMenuOpen) toggleMenu(item.id);
                      else setActiveMenu(item.id);
                    }}
                    onFocus={() => {
                      if (!mobileMenuOpen) setActiveMenu(item.id);
                    }}
                    type="button"
                  >
                    {item.label}
                    <Icon name="chevron" size={14} />
                  </button>
                ) : item.items ? (
                  <div className="nav-trigger nav-trigger-with-toggle">
                    <Link
                      className="nav-trigger-link"
                      href={resolveHref(item.href)}
                      onClick={() => {
                        setMobileMenuOpen(false);
                        setActiveMenu(null);
                      }}
                    >
                      {item.label}
                    </Link>
                    <button
                      aria-expanded={activeMenu === item.id}
                      aria-label={`${activeMenu === item.id ? "Tutup" : "Buka"} submenu ${item.label}`}
                      className="nav-trigger-toggle"
                      onClick={() => toggleMenu(item.id)}
                      type="button"
                    >
                      <Icon name="chevron" size={14} />
                    </button>
                  </div>
                ) : (
                  <Link
                    className="nav-trigger"
                    href={resolveHref(item.href ?? "#kabar")}
                    onClick={() => {
                      setMobileMenuOpen(false);
                      setActiveMenu(null);
                    }}
                  >
                    {item.label}
                    {item.items && <Icon name="chevron" size={14} />}
                  </Link>
                )}
                {item.items && (
                  <div
                    aria-hidden={activeMenu !== item.id}
                    className={`nav-dropdown${item.id === "akademik" || item.id === "profil" ? " academic-dropdown" : ""}${activeMenu === item.id ? " is-open" : ""}`}
                  >
                    <GlobalDropdownMenu
                      className={item.id === "lpm" ? "menu-tree lpm-menu-tree" : "menu-tree"}
                      expandActiveNodes={false}
                      items={item.items}
                      key={`${item.id}-${pathname}-${activeMenu === item.id}`}
                      onNavigate={() => {
                        setMobileMenuOpen(false);
                        setActiveMenu(null);
                      }}
                      pathname={pathname}
                    />
                  </div>
                )}
              </div>
            );
          })}

          <Link
            className="button button-primary nav-apply"
            href="/pmb"
            onClick={() => setMobileMenuOpen(false)}
          >
            Daftar Sekarang <Icon name="arrow" size={16} />
          </Link>
        </nav>
      </div>
      <GlobalSearch
        isOpen={searchOpen}
        onClose={closeSearch}
        triggerRef={searchTriggerRef}
      />
      <SiteTranslator />
    </header>
  );
}

export function SiteBreadcrumb() {
  const pathname = usePathname();
  if (pathname?.startsWith("/admin")) {
    return null;
  }
  const items = getBreadcrumbItems(pathname);

  return (
    <nav aria-label="Breadcrumb" className="site-breadcrumb">
      {items.map((item, index) => (
        <span className="site-breadcrumb-item" key={`${item.label}-${index}`}>
          {index > 0 && <span aria-hidden="true">/</span>}
          {index === items.length - 1 ? (
            <span aria-current="page">{item.label}</span>
          ) : item.href ? (
            <Link href={item.href}>{item.label}</Link>
          ) : (
            <span>{item.label}</span>
          )}
        </span>
      ))}
    </nav>
  );
}

export function SiteFooter({ className = "" }: { className?: string }) {
  const pathname = usePathname();
  if (pathname?.startsWith("/admin")) {
    return null;
  }
  return (
    <footer className={`site-footer ${className}`} id="footer">
      <div className="footer-main content-wrap">
        <div className="footer-about">
          <Link aria-label="Universitas LIA, Beranda" className="brand footer-brand" href="/">
            <Image
              alt="Universitas LIA"
              className="brand-logo"
              height={41}
              src="/Logo-Universitas-LIA-scaled.png"
              width={180}
            />
          </Link>
          <p>
            Universitas LIA adalah titik temu antara teknologi dan kepakaran
            dalam pengajaran bahasa asing.
          </p>
          <div className="social-links">
            <a aria-label="Instagram" href="#footer">ig</a>
            <a aria-label="YouTube" href="#footer">▶</a>
            <a aria-label="LinkedIn" href="#footer">in</a>
          </div>
        </div>
        <div className="footer-column">
          <h3>Universitas</h3>
          <Link href="/profil">Profil Universitas</Link>
          <Link href="/lppm">LPPM</Link>
          <Link href="/lpm">LPM</Link>
          <Link href="/alumni">Alumni</Link>
          <Link href="/laporan-tahunan-rektor">Laporan Tahunan Rektor</Link>
        </div>
        <div className="footer-column">
          <h3>Informasi &amp; layanan</h3>
          <Link href="/akademik/fakultas">Akademik</Link>
          <Link href="/pmb">Penerimaan Mahasiswa Baru</Link>
          <Link href="/pengunduran-diri">Pengunduran Diri</Link>
          <Link href="/#footer">SIAKAD UL</Link>
          <Link href="/#footer">Edlink</Link>
          <Link href="/profil/unit-dan-bagian/upt-perpustakaan">Perpustakaan Universitas LIA</Link>
        </div>
        <div className="footer-column footer-contact">
          <h3>Hubungi kami</h3>
          <p>Alamat: Jl. Pengadegan Timur Raya No.3</p>
          <p>Email: humas@universitaslia.ac.id</p>
          <p>WhatsApp: 0858-8103-6948</p>
        </div>
      </div>
      <div className="footer-bottom content-wrap">
        <small>© Universitas LIA. Seluruh hak cipta dilindungi.</small>
        <div>
          <Link href="/#footer">Kebijakan Privasi</Link>
          <Link href="/#footer">Peta Situs</Link>
        </div>
      </div>
    </footer>
  );
}